/// cerinta 3-
#include<iostream>
using namespace std;
int V[100];
int n;
int main()
{
cout<<"n=";cin>>n;
for(int i=1;i<=n;i=i+1)
{cout<<"V["<<i<<"]=";cin>>V[i];}
int gata=0;
while   (gata==0)
{
        gata=1;
        for(int i=1;i<=n-1;i=i+1)
        { if ( V[i] < V[i+1]  ) {
                                        swap(V[i],V[i+1]);
                                        gata=0;
                                       }
        }
}
cout<<endl<<"Sortate : "<<endl;
for(int i=1;i<=n;i=i+1)
        cout<<V[i]<<" ";
}
